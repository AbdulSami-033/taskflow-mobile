// In the ROOT build.gradle.kts (build.gradle.kts)

plugins {
    id("com.android.application") version "8.13.2" apply false // Or your current AGP version
    id("com.android.library") version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.27" apply false
}

// Allprojects and Subprojects configuration (if present) usually go here